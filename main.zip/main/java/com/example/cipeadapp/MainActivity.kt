package com.example.cipeadapp


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp



class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    TelaCipead()
                }
            }
        }
    }
}

@Composable
fun TelaCipead() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(Icons.Default.Menu, contentDescription = "Menu")
            Text("UFPR", fontSize = 14.sp, color = Color.Gray)
            Icon(Icons.Default.Search, contentDescription = "Buscar")
        }
        Image(
            painter = painterResource(R.drawable.ufprlogo),
            contentDescription = "Logo UFPR",


            modifier = Modifier.size(200.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text("CIPEAD/UFPR", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF003366))
        Text("Centro de Educação a Distância", fontSize = 14.sp)

        Spacer(modifier = Modifier.height(16.dp))


        Button(
            onClick = { },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700))
        ) {
            Text("Acessar Moodle", color = Color.Black)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("Cursos", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF003366))

        Spacer(modifier = Modifier.height(8.dp))

        CursoCard("Curso 1", "Introdução à Educação a Distância")
        CursoCard("Curso 2", "Tecnologias Digitais na Educação")
        CursoCard("Curso 3", "Metodologias Ativas de Aprendizagem")
    }
}

@Composable
fun CursoCard(titulo: String, subtitulo: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(titulo, fontWeight = FontWeight.Bold, color = Color(0xFF003366))
            Text(subtitulo, fontSize = 14.sp)


        }
    }
}
